# e-calculator
# =======================================================
# This is the individual project of Online Academy Digital Talent Scholarship, Indonesian Ministry of Informatics and Communications
# It's the web-based calculator with HTML, CSS and JavaScript
# This calculator can do a basic operations (+ - * / =), percentage and All Clear (AC) feature
# The next feature will be soon
